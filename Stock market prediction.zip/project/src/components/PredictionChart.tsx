import React, { useEffect, useRef } from 'react';
import { StockData } from '../types/stock';
import { Brain, TrendingUp } from 'lucide-react';

interface PredictionChartProps {
  stock: StockData;
}

export const PredictionChart: React.FC<PredictionChartProps> = ({ stock }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth * 2;
    canvas.height = 400 * 2;
    ctx.scale(2, 2);

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Generate sample data
    const basePrice = stock.currentPrice;
    const historicalData = Array.from({ length: 30 }, (_, i) => ({
      x: i,
      y: basePrice + Math.sin(i * 0.2) * 10 + (Math.random() - 0.5) * 5
    }));

    const predictionData = Array.from({ length: 7 }, (_, i) => ({
      x: 30 + i,
      y: basePrice + Math.sin((30 + i) * 0.2) * 10 + (Math.random() - 0.5) * 5 + i * 2
    }));

    const width = canvas.offsetWidth;
    const height = 400;
    const padding = 50;

    // Find min/max for scaling
    const allData = [...historicalData, ...predictionData];
    const minY = Math.min(...allData.map(d => d.y)) - 5;
    const maxY = Math.max(...allData.map(d => d.y)) + 5;
    const minX = 0;
    const maxX = 36;

    // Scale functions
    const scaleX = (x: number) => ((x - minX) / (maxX - minX)) * (width - 2 * padding) + padding;
    const scaleY = (y: number) => height - (((y - minY) / (maxY - minY)) * (height - 2 * padding) + padding);

    // Draw grid
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.1)';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 10; i++) {
      const y = (height - 2 * padding) * (i / 10) + padding;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }

    // Draw historical line
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    historicalData.forEach((point, i) => {
      const x = scaleX(point.x);
      const y = scaleY(point.y);
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });
    
    ctx.stroke();

    // Draw prediction line
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    
    const lastHistorical = historicalData[historicalData.length - 1];
    ctx.moveTo(scaleX(lastHistorical.x), scaleY(lastHistorical.y));
    
    predictionData.forEach((point) => {
      const x = scaleX(point.x);
      const y = scaleY(point.y);
      ctx.lineTo(x, y);
    });
    
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw prediction confidence area
    ctx.fillStyle = 'rgba(16, 185, 129, 0.1)';
    ctx.beginPath();
    ctx.moveTo(scaleX(lastHistorical.x), scaleY(lastHistorical.y));
    
    predictionData.forEach((point) => {
      ctx.lineTo(scaleX(point.x), scaleY(point.y + 5));
    });
    
    for (let i = predictionData.length - 1; i >= 0; i--) {
      ctx.lineTo(scaleX(predictionData[i].x), scaleY(predictionData[i].y - 5));
    }
    
    ctx.lineTo(scaleX(lastHistorical.x), scaleY(lastHistorical.y));
    ctx.fill();

    // Draw current price point
    const currentX = scaleX(29);
    const currentY = scaleY(stock.currentPrice);
    
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(currentX, currentY, 6, 0, 2 * Math.PI);
    ctx.fill();

    // Draw labels
    ctx.fillStyle = '#e2e8f0';
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('Historical', padding, 25);
    
    ctx.fillStyle = '#10b981';
    ctx.fillText('AI Prediction', padding + 100, 25);

  }, [stock]);

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Brain className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Price Prediction Chart</h3>
        </div>
        <div className="flex items-center space-x-2 text-green-400">
          <TrendingUp className="w-5 h-5" />
          <span className="text-sm font-medium">Bullish Trend Detected</span>
        </div>
      </div>
      
      <div className="relative">
        <canvas
          ref={canvasRef}
          className="w-full h-96 rounded-lg"
          style={{ background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.8), rgba(30, 41, 59, 0.4))' }}
        />
        
        <div className="flex justify-between items-center mt-4 text-sm text-slate-400">
          <span>30 days ago</span>
          <span className="text-yellow-400 font-medium">Current: ${stock.currentPrice.toFixed(2)}</span>
          <span>7 days prediction</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="bg-slate-700/30 rounded-lg p-4 text-center">
          <p className="text-slate-400 text-sm">Support Level</p>
          <p className="text-2xl font-bold text-red-400">${(stock.currentPrice * 0.95).toFixed(2)}</p>
        </div>
        <div className="bg-slate-700/30 rounded-lg p-4 text-center">
          <p className="text-slate-400 text-sm">Target Price</p>
          <p className="text-2xl font-bold text-green-400">${(stock.currentPrice * 1.08).toFixed(2)}</p>
        </div>
        <div className="bg-slate-700/30 rounded-lg p-4 text-center">
          <p className="text-slate-400 text-sm">Resistance Level</p>
          <p className="text-2xl font-bold text-yellow-400">${(stock.currentPrice * 1.12).toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
};