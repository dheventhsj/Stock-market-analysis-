import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { StockData } from '../types/stock';

interface SearchBarProps {
  onSearch: (query: string) => void;
  results: StockData[];
  onSelectStock: (stock: StockData) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ onSearch, results, onSelectStock }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    onSearch(value);
    setIsOpen(value.length > 0);
  };

  const handleSelectStock = (stock: StockData) => {
    onSelectStock(stock);
    setQuery('');
    setIsOpen(false);
  };

  const clearSearch = () => {
    setQuery('');
    setIsOpen(false);
    onSearch('');
  };

  return (
    <div className="relative">
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
        <div className="flex items-center space-x-2 mb-4">
          <Search className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Search Stocks</h3>
        </div>
        
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={handleInputChange}
            placeholder="Search by symbol or company name..."
            className="w-full bg-slate-700/50 border border-slate-600/50 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500/50 focus:bg-slate-700/70 transition-all duration-200"
          />
          
          {query && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white transition-colors duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {isOpen && results.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-700/50 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
            {results.map((stock) => (
              <div
                key={stock.symbol}
                onClick={() => handleSelectStock(stock)}
                className="p-3 hover:bg-slate-700/50 cursor-pointer border-b border-slate-700/30 last:border-b-0 transition-colors duration-200"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-white text-sm">{stock.symbol}</h4>
                    <p className="text-xs text-slate-400 truncate">{stock.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium text-sm">${stock.currentPrice.toFixed(2)}</p>
                    <p className={`text-xs ${stock.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};