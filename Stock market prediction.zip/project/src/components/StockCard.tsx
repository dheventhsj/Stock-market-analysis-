import React from 'react';
import { TrendingUp, TrendingDown, Plus, Brain } from 'lucide-react';
import { StockData } from '../types/stock';

interface StockCardProps {
  stock: StockData;
  onAddToWatchlist: (stock: StockData) => void;
}

export const StockCard: React.FC<StockCardProps> = ({ stock, onAddToWatchlist }) => {
  const isPositive = stock.change >= 0;
  const changePercent = ((stock.change / (stock.currentPrice - stock.change)) * 100).toFixed(2);

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-300">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-white">{stock.symbol}</h2>
          <p className="text-slate-400">{stock.name}</p>
        </div>
        <button
          onClick={() => onAddToWatchlist(stock)}
          className="p-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors duration-200 group"
        >
          <Plus className="w-5 h-5 text-white group-hover:scale-110 transition-transform duration-200" />
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div>
          <p className="text-slate-400 text-sm">Current Price</p>
          <p className="text-3xl font-bold text-white">${stock.currentPrice.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-slate-400 text-sm">Change</p>
          <div className="flex items-center space-x-1">
            {isPositive ? (
              <TrendingUp className="w-5 h-5 text-green-400" />
            ) : (
              <TrendingDown className="w-5 h-5 text-red-400" />
            )}
            <span className={`text-xl font-semibold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? '+' : ''}{stock.change.toFixed(2)}
            </span>
          </div>
        </div>
        <div>
          <p className="text-slate-400 text-sm">Change %</p>
          <p className={`text-xl font-semibold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{changePercent}%
          </p>
        </div>
        <div>
          <p className="text-slate-400 text-sm">Volume</p>
          <p className="text-xl font-semibold text-white">{stock.volume.toLocaleString()}</p>
        </div>
      </div>

      <div className="bg-slate-700/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Brain className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">AI Analysis</h3>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed">
          Based on technical analysis and market sentiment, our AI model predicts a{' '}
          <span className="text-green-400 font-semibold">bullish trend</span> for {stock.symbol} 
          over the next 7 days. Key indicators show strong momentum with a confidence level of{' '}
          <span className="text-yellow-400 font-semibold">78.5%</span>.
        </p>
      </div>
    </div>
  );
};