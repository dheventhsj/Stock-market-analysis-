import React from 'react';
import { Eye, TrendingUp, TrendingDown } from 'lucide-react';
import { StockData } from '../types/stock';

interface WatchlistProps {
  stocks: StockData[];
  onSelectStock: (stock: StockData) => void;
  selectedSymbol: string;
}

export const Watchlist: React.FC<WatchlistProps> = ({ stocks, onSelectStock, selectedSymbol }) => {
  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
      <div className="flex items-center space-x-2 mb-4">
        <Eye className="w-5 h-5 text-blue-400" />
        <h3 className="text-lg font-semibold text-white">Watchlist</h3>
      </div>
      
      <div className="space-y-3">
        {stocks.map((stock) => {
          const isPositive = stock.change >= 0;
          const isSelected = stock.symbol === selectedSymbol;
          
          return (
            <div
              key={stock.symbol}
              onClick={() => onSelectStock(stock)}
              className={`p-3 rounded-lg cursor-pointer transition-all duration-200 hover:bg-slate-700/50 ${
                isSelected ? 'bg-blue-600/20 border border-blue-500/50' : 'bg-slate-700/30'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h4 className="font-semibold text-white text-sm">{stock.symbol}</h4>
                  <p className="text-xs text-slate-400 truncate">{stock.name}</p>
                </div>
                {isPositive ? (
                  <TrendingUp className="w-4 h-4 text-green-400" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-400" />
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-white font-medium">${stock.currentPrice.toFixed(2)}</span>
                <span className={`text-xs font-medium ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                  {isPositive ? '+' : ''}{stock.change.toFixed(2)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};