import React from 'react';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export const MarketOverview: React.FC = () => {
  const marketData = [
    { name: 'S&P 500', value: '4,785.32', change: '+21.45', changePercent: '+0.45%', isPositive: true },
    { name: 'NASDAQ', value: '14,912.34', change: '+67.89', changePercent: '+0.46%', isPositive: true },
    { name: 'DOW JONES', value: '37,248.65', change: '-45.21', changePercent: '-0.12%', isPositive: false },
    { name: 'RUSSELL 2000', value: '2,034.56', change: '+12.34', changePercent: '+0.61%', isPositive: true },
  ];

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
      <div className="flex items-center space-x-2 mb-4">
        <Activity className="w-6 h-6 text-blue-400" />
        <h3 className="text-xl font-semibold text-white">Market Overview</h3>
        <div className="ml-auto flex items-center space-x-2 text-sm text-slate-400">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Live</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {marketData.map((market) => (
          <div key={market.name} className="bg-slate-700/30 rounded-lg p-4 hover:bg-slate-700/50 transition-colors duration-200">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-white text-sm">{market.name}</h4>
              {market.isPositive ? (
                <TrendingUp className="w-4 h-4 text-green-400" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-400" />
              )}
            </div>
            <p className="text-lg font-bold text-white mb-1">{market.value}</p>
            <div className="flex items-center space-x-2">
              <span className={`text-sm font-medium ${market.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {market.change}
              </span>
              <span className={`text-xs ${market.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {market.changePercent}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};