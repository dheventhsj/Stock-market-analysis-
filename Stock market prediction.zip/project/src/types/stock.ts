export interface StockData {
  symbol: string;
  name: string;
  currentPrice: number;
  change: number;
  volume: number;
  marketCap?: number;
  pe?: number;
  dividend?: number;
}