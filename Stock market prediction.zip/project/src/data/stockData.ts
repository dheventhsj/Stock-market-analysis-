import { StockData } from '../types/stock';

export const stockData: StockData[] = [
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    currentPrice: 192.75,
    change: 2.45,
    volume: 45678900,
    marketCap: 3020000000000,
    pe: 28.5,
    dividend: 0.96
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    currentPrice: 141.22,
    change: -1.18,
    volume: 23456700,
    marketCap: 1780000000000,
    pe: 25.2,
    dividend: 0
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    currentPrice: 378.85,
    change: 4.67,
    volume: 19876500,
    marketCap: 2810000000000,
    pe: 32.1,
    dividend: 2.72
  },
  {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    currentPrice: 153.44,
    change: -2.31,
    volume: 34567800,
    marketCap: 1590000000000,
    pe: 42.8,
    dividend: 0
  },
  {
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    currentPrice: 238.59,
    change: 8.92,
    volume: 87654300,
    marketCap: 758000000000,
    pe: 65.4,
    dividend: 0
  },
  {
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    currentPrice: 481.23,
    change: 12.78,
    volume: 45123600,
    marketCap: 1180000000000,
    pe: 78.2,
    dividend: 0.16
  },
  {
    symbol: 'META',
    name: 'Meta Platforms Inc.',
    currentPrice: 334.87,
    change: -3.45,
    volume: 18976500,
    marketCap: 848000000000,
    pe: 24.7,
    dividend: 0
  },
  {
    symbol: 'NFLX',
    name: 'Netflix Inc.',
    currentPrice: 485.73,
    change: 7.89,
    volume: 3456780,
    marketCap: 215000000000,
    pe: 35.6,
    dividend: 0
  },
  {
    symbol: 'AMD',
    name: 'Advanced Micro Devices',
    currentPrice: 118.44,
    change: -1.67,
    volume: 32145600,
    marketCap: 191000000000,
    pe: 145.2,
    dividend: 0
  },
  {
    symbol: 'INTC',
    name: 'Intel Corporation',
    currentPrice: 43.28,
    change: 0.89,
    volume: 28765400,
    marketCap: 183000000000,
    pe: 15.8,
    dividend: 0.50
  }
];